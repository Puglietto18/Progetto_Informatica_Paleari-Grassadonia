package com.example.scontrinoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    ArrayList<Prodotto> carrello;
    TextView txtScontrino;
    Button btnAcquista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtScontrino = findViewById(R.id.txtScontrino);
        btnAcquista = findViewById(R.id.btnAcquista);

        carrello = new ArrayList<>();

        carrello.add(new Prodotto("Pane", 1.50, 2));
        carrello.add(new Prodotto("Latte", 1.20, 1));
        carrello.add(new Prodotto("Pasta", 0.90, 3));

        btnAcquista.setOnClickListener(v -> {
            txtScontrino.setText(generaScontrino());
        });
    }

    private String generaScontrino() {
        StringBuilder scontrino = new StringBuilder();
        double totale = 0;

        String data = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());

        scontrino.append("---- SCONTRINO ----\n");
        scontrino.append("Data: ").append(data).append("\n\n");

        for (Prodotto p : carrello) {
            scontrino.append(p.getNome())
                    .append(" x")
                    .append(p.getQuantita())
                    .append(" - €")
                    .append(String.format("%.2f", p.getTotale()))
                    .append("\n");

            totale += p.getTotale();
        }

        scontrino.append("\n-------------------\n");
        scontrino.append("Totale: €").append(String.format("%.2f", totale));

        return scontrino.toString();
    }
}
