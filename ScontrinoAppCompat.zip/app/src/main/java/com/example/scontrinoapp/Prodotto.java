package com.example.scontrinoapp;

public class Prodotto {
    private String nome;
    private double prezzo;
    private int quantita;

    public Prodotto(String nome, double prezzo, int quantita) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.quantita = quantita;
    }

    public String getNome() { return nome; }
    public int getQuantita() { return quantita; }

    public double getTotale() {
        return prezzo * quantita;
    }
}
